var config = {
    "deps": [
        "Magento_Theme/js/mobile-links"
    ]
};
